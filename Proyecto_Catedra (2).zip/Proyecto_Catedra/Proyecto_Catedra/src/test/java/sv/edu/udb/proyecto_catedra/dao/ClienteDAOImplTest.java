package sv.edu.udb.proyecto_catedra.dao;

import static org.junit.jupiter.api.Assertions.*;

class ClienteDAOImplTest {

}