package sv.edu.udb.proyecto_catedra.model;

public enum Estado {
    ACTIVO,
    INACTIVO,
    EN_PROCESO,
    FINALIZADA
}
