package sv.edu.udb.proyecto_catedra.model;

public enum TipoPersona {
    NATURAL,
    JURIDICA
}
