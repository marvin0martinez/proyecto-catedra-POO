package sv.edu.udb.proyecto_catedra.model;

public enum TipoContratacion {
    PERMANENTE,
    POR_HORAS
}
